// Copyright (c) 2020 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React from 'react'
import { List, Icon} from 'semantic-ui-react'
import { User } from '@daml.js/create-daml-app';
import { Party } from '@daml/types';

type Props = {
  outstandingFriendRequests: User.FriendRequest.Key[];
  onCancel: (friendRequest: User.FriendRequest.Key) => void;
  partyToAlias: Map<Party, string>;
}

/**
 * React component to display a list of `FriendRequest`s.
 */
const OutstandingFriendRequestList: React.FC<Props> = ({outstandingFriendRequests, onCancel, partyToAlias}) => {
  return (
    <List divided relaxed>
      {[...outstandingFriendRequests].sort((x, y) => x._2.localeCompare(y._2)).map(friendRequest=>
        <List.Item key={friendRequest._2}>
          <List.Icon name='user outline' />
          <List.Content>
            <List.Content floated='right'>
              <Icon
                name='cancel'
                link
                className='test-select-add-user-icon'
                onClick={() => onCancel(friendRequest)} />
            </List.Content>
            <List.Header>{partyToAlias.get(friendRequest._2) ?? friendRequest._2}</List.Header>
          </List.Content>
        </List.Item>
      )}
    </List>
  );
};

export default OutstandingFriendRequestList;
