// Copyright (c) 2020 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React from 'react';
import { Container, Grid, Header, Icon, Segment, Divider } from 'semantic-ui-react';
import { Party } from '@daml/types';
import { User } from '@daml.js/create-daml-app';
import { useParty, useLedger, useStreamFetchByKey, useStreamQuery } from '@daml/react';
import FriendsList from './FriendsList';
import FriendRequestList from './FriendRequestList';
import OutstandingFriendRequestList from './OutstandingFriendRequestList';
import MessageEdit from './MessageEdit';
import MessageList from './MessageList';

// USERS_BEGIN
const MainView: React.FC = () => {
  const username = useParty();
  const myUserResult = useStreamFetchByKey(User.User, () => username, [username]);
  const myUser = myUserResult.contract?.payload;
  const friendRequests = useStreamQuery(User.FriendRequest)
                          .contracts.map(c => c.key)
                          .filter(k => k._1 !== username);
  const outstandingFriendRequests = useStreamQuery(User.FriendRequest)
                          .contracts.map(c => c.key)
                          .filter(k => k._1 === username)
  const friends = useStreamQuery(User.Friendship)
                    .contracts
                    .map(c => c.key)
// USERS_END

  const ledger = useLedger();

  const createFriendRequest = async (friend: Party): Promise<boolean> => {
    try {
      await ledger.exerciseByKey(User.User.NewFriendRequest, username, {friend});
      return true;
    } catch (error){
      alert("Unknown error:\n" + JSON.stringify(error));
      return false;
    }
  }

  const cancelFriendRequest = async (friendRequest: User.FriendRequest.Key): Promise<boolean> => {
    try {
      await ledger.exerciseByKey(User.FriendRequest.CancelFriendRequest, friendRequest, {});
      return true;
    } catch (error){
      alert("Unknown error:\n" + JSON.stringify(error));
      return false;
    }
  }

  const acceptFriendRequest = async (friendRequest: User.FriendRequest.Key): Promise<boolean> => {
    try {
      await ledger.exerciseByKey(User.User.AcceptFriendRequest, username, {friendRequest});
      return true;
    } catch (error) {
      alert("Unknown error:\n" + JSON.stringify(error));
      return false;
    }
  }

  const cancelFriendship = async (friendship: User.Friendship.Key): Promise<boolean> => {
    try {
      if (friendship._1 === username) {
        await ledger.exerciseByKey(User.Friendship.CancelFriendship1, friendship, {});
      } else {
        await ledger.exerciseByKey(User.Friendship.CancelFriendship2, friendship, {});
      };
      return true;
    } catch (error){
      alert("Unknown error:\n" + JSON.stringify(error));
      return false;
    }
  }

  return (
    <Container>
      <Grid centered columns={2}>
        <Grid.Row stretched>
          <Grid.Column>
            <Header as='h1' size='huge' color='blue' textAlign='center' style={{padding: '1ex 0em 0ex 0em'}}>
                {myUser ? `Welcome, ${myUser.username}!` : 'Loading...'}
            </Header>

            <Segment>
              <Header as='h2'>
                <Icon name='user' />
                <Header.Content>
                  {myUser?.username ?? 'Loading...'}
                  <Header.Subheader>My friends</Header.Subheader>
                </Header.Content>
              </Header>
              <Divider />
              <FriendsList
                friends={friends}
                onCancel={cancelFriendship}
                onCreateFriendRequest={createFriendRequest}
              />
            </Segment>
            <Segment>
              <Header as='h2'>
                <Icon name='handshake' />
                <Header.Content>
                  Friend requests
                </Header.Content>
              </Header>
              <Divider/>
              <FriendRequestList
                friendRequests={friendRequests}
                onAccept={acceptFriendRequest}
              />
              <Header as='h5'>
                <Header.Content>
                  Outstanding friend requests
                </Header.Content>
              </Header>
              <Divider/>
              <OutstandingFriendRequestList
                outstandingFriendRequests={outstandingFriendRequests}
                onCancel={cancelFriendRequest}
              />

            </Segment>
            <Segment>
              <Header as='h2'>
                <Icon name='pencil square' />
                <Header.Content>
                  Messages
                  <Header.Subheader>Send a message to a follower</Header.Subheader>
                </Header.Content>
              </Header>
              <MessageEdit/>
                <Divider/>
              <MessageList />
            </Segment>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </Container>
  );
}

export default MainView;
