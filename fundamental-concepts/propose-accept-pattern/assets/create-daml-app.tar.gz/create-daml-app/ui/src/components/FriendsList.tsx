// Copyright (c) 2020 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React from 'react'
import { Form, List, Button, Icon } from 'semantic-ui-react';
import { Party } from '@daml/types';
import { User } from '@daml.js/create-daml-app';
import { useParty } from '@daml/react';

type Props = {
  friends: User.Friendship.Key[];
  onCancel: (friendship: User.Friendship.Key) => Promise<boolean>;
  onCreateFriendRequest: (friend: Party) => Promise<boolean>;
}

/**
 * React component to edit a list of `Party`s.
 */
const FriendList: React.FC<Props> = ({friends, onCreateFriendRequest, onCancel}) => {
  const username = useParty();
  const [newParty, setNewParty] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const addParty = async (event?: React.FormEvent) => {
    if (event) {
      event.preventDefault();
    }
    setIsSubmitting(true);
    const success = await onCreateFriendRequest(newParty);
    setIsSubmitting(false);
    if (success) {
      setNewParty('');
    }
  }

  const getFriend = (friendship: User.Friendship.Key) => {
    return friendship._1 === username ? friendship._2 : friendship._1
  }

  return (
    <List relaxed>
      {[...friends].map((friendship) =>
        <List.Item key={getFriend(friendship)}>
          <List.Icon name='user' />
          <List.Content>
            <List.Content floated='right'>
              <Icon
                name='cancel'
                link
                onClick={() => onCancel(friendship)} />
            </List.Content>
            <List.Header>
              {getFriend(friendship)}
            </List.Header>
        </List.Content>
        </List.Item>
      )}
      <br />
      <Form onSubmit={addParty}>
        <Form.Input
          fluid
          readOnly={isSubmitting}
          loading={isSubmitting}
          className='test-select-follow-input'
          placeholder="Username to create a friend request for"
          value={newParty}
          onChange={(event) => setNewParty(event.currentTarget.value)}
        />
        <Button
          type='submit'
          >
          Create friend request
        </Button>
      </Form>
    </List>
  );
};

export default FriendList;
