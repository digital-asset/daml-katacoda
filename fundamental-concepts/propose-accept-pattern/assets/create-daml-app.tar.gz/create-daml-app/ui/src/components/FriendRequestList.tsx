// Copyright (c) 2020 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React from 'react'
import { Icon, List } from 'semantic-ui-react'
import { User } from '@daml.js/create-daml-app';
import { Party } from '@daml/types';

type Props = {
  friendRequests: User.FriendRequest.Key[];
  onAccept: (friendRequest: User.FriendRequest.Key) => void;
  partyToAlias: Map<Party, string>;
}

/**
 * React component to display a list of `FriendRequest`s.
 */
const FriendRequestList: React.FC<Props> = ({friendRequests, onAccept, partyToAlias}) => {
  return (
    <List divided relaxed>
      {[...friendRequests].sort((x, y) => x._1.localeCompare(y._1)).map(friendRequest=>
        <List.Item key={friendRequest._1}>
          <List.Icon name='user' />
          <List.Content>
            <List.Content floated='right'>
              <Icon
                name='add user'
                link
                className='test-select-add-user-icon'
                onClick={() => onAccept(friendRequest)} />
            </List.Content>
            <List.Header className='test-select-user-in-network'>{partyToAlias.get(friendRequest._1) ?? friendRequest._1}</List.Header>
          </List.Content>
        </List.Item>
      )}
    </List>
  );
};

export default FriendRequestList;
