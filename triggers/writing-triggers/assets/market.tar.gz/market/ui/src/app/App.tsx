import DamlLedger from '@daml/react';
import React, { useState } from 'react';
import LoginScreen from '../components/LoginScreen';
import MainScreen from '../components/MainScreen';
import Credentials from '../Credentials';
import {httpBaseUrl} from '../config';

type Cards = {
  kind: 'cards';
}

type Invoices = {
  kind: 'invoices';
}

export type View = Cards | Invoices;


/**
 * React component for the entry point into the application.
 */
const App: React.FC = () => {
  const [view, setView] = useState<View>({kind: 'cards'});
  const [credentials, setCredentials] = React.useState<Credentials | undefined>();
  const onLogin = (credentials: Credentials) => {
    setCredentials(credentials);
    setView({kind: 'cards'})
  };


  return credentials
    ?
      <DamlLedger
        party = {credentials.party}
        token = {credentials.token}
        httpBaseUrl={httpBaseUrl}
      >
        <MainScreen
          handleLogOut={() => setCredentials(undefined)}
          handleGoToInvoices={() => setView({kind: 'invoices'})}
          handleGoToCards={() => setView({kind: 'cards'})}
          activeView={view}
        />
      </DamlLedger>

    : <LoginScreen onLogin={onLogin}/>
}


export default App;
