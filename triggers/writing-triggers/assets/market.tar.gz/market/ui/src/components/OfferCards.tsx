import React from 'react'
import {Card} from 'semantic-ui-react'
import {OfferCard} from './OfferCard'
import {useParty, useStreamQuery, useLedger} from '@daml/react'
import * as market from '@daml.js/market'
import {toast} from 'react-semantic-toasts'
import {CreateEvent} from '@daml/ledger'



const OfferCards: React.FC = () =>
{
  const party = useParty();
  const sellOffers = useStreamQuery(market.Market.SellOffer, () => ({}), [party]);
  const ledger = useLedger();
  const handleTakeOfferRequest = async (sellOffer: CreateEvent<market.Market.SellOffer>) => {
    await ledger.exerciseByKey(market.Market.User.TakeSellOffer, party, {offer: sellOffer.contractId});
    toast({
      title: 'Success',
      type: 'success',
      time: 3000,
      description: 'You bought ' + sellOffer.payload.title + '!',
    });
  }

  return (
    <Card.Group>
        {sellOffers.contracts.map(sellOffer =>
          <OfferCard
            offer={sellOffer.payload}
            handleTakeOffer={() => handleTakeOfferRequest(sellOffer)}
          >
          </OfferCard>
        )}
    </Card.Group>
  )
}

export default OfferCards;
