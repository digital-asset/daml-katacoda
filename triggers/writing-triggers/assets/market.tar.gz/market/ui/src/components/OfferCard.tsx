import React from 'react';
import { Button, Card} from 'semantic-ui-react';
import { SellOffer } from '@daml.js/market/lib/Market';

type Props = {
  offer: SellOffer;
  handleTakeOffer: () => void;
}

export const OfferCard: React.FC<Props> = ({offer, handleTakeOffer}) => {
    return (
      <Card>
        <Card.Content>
          <Card.Header>
            {offer.title}
          </Card.Header>
          <Card.Meta>
            <span className='date'> {offer.date} </span>
            <span className='date'> by {offer.seller} </span>
          </Card.Meta>
          <Card.Description>
            {offer.description}
          </Card.Description>
        </Card.Content>
        <Card.Content>
            {offer.price} USD
            <Button basic color='orange' floated='right' content='Take offer' onClick={handleTakeOffer}/>
        </Card.Content>
      </Card>
    );
};

export default OfferCard;
