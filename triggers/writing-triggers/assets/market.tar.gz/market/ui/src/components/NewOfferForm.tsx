import React from 'react';
import {toast} from 'react-semantic-toasts';
import {Button, Form, FormProps, Input, TextArea} from 'semantic-ui-react';
import {useParty, useLedger} from '@daml/react';
import * as market from '@daml.js/market';

type Props = {
    handleCloseForm: () => void;
};

const NewOfferForm: React.FC<Props> = ({handleCloseForm}) => {
  const party = useParty();
  const [currentForm, setState] = React.useState<market.Market.NewSellOffer>(
      {title:''
        , description:''
        , price:''
        , observers: []}
  );

  const ledger = useLedger();

  const onChange = (e: any, {name, value}: any) => {
    if (e)
      e.preventDefault()
    if (name === 'client')
      setState({...currentForm, observers:[value]})
    else
      setState({...currentForm, [name]:value})
  };

  const handleSubmit = async (event: React.FormEvent<HTMLElement>, data: FormProps) => {
    if (event)
      event.preventDefault();

    await ledger.exerciseByKey(market.Market.User.NewSellOffer, party, currentForm);
    handleCloseForm();
    toast({
      title: 'Success',
      type: 'success',
      time: 3000,
      description: 'Created new offer.',
    });
  };

  return(
    <Form onSubmit={handleSubmit}>
      <Form.Field
        label='Client'
        control={Input}
        placeholder='Client'
        name='client'
        onChange={onChange}
      >
      </Form.Field>
      <Form.Field
        label='Title'
        control={Input}
        placeholder='Title'
        name='title'
        onChange={onChange}
      >
      </Form.Field>
      <Form.Field
        label='Description'
        name='description'
        control={TextArea}
        placeholder='Describe your offer'
        onChange={onChange}
      >
      </Form.Field>
      <Input
        placeholder='Price'
        labelPosition='right'
        name='price'
        onChange={onChange}
      >
      </Input>
      <Form.Group>
        <Form.Field control={Button}> Submit </Form.Field>
        <Form.Field control={Button} onClick={handleCloseForm}> Cancel </Form.Field>
      </Form.Group>
    </Form>
  );
};

export default NewOfferForm;
