import {useParty} from '@daml/react';
import React, {useState} from 'react';
import {Container, Image, Menu} from 'semantic-ui-react';
import {View} from '../app/App';
import CreditDebitList from './CreditDebitList';
import NewOfferModal from './NewOfferModal';
import OfferCards from './OfferCards';

type Props = {
  handleLogOut: () => void;
  handleGoToInvoices: () => void;
  handleGoToCards: () => void;
  activeView: View;
}

/**
 * React component for the main screen of the `App`.
 */
const MainScreen: React.FC<Props> = (props) => {
  const party = useParty();
  const [newOfferFormOpen, openNewOfferForm] = useState(false);
  const handleNewOfferFormOpen = () => openNewOfferForm(true);
  const handleNewOfferFormClose = () => openNewOfferForm(false);

  const branchView = (props: Props) => {
    switch (props.activeView.kind) {
      case 'invoices' :
        return(
          <>
           <CreditDebitList>
           </CreditDebitList>
          </>
        )
      case 'cards' :
        return (
          <>
            <OfferCards />
          </>
        )
    }
  }
  return (
    <>
      <Menu icon borderless>
        <Menu.Item>
          <Image
            as='a'
            href='https://www.daml.com/'
            target='_blank'
            src='/daml.svg'
            alt='DAML Logo'
            size='mini'
          />
        </Menu.Item>
        <Menu.Menu position='right'>
          <Menu.Item position='right'>
            You are logged in as &nbsp; <strong>{party}</strong>.
          </Menu.Item>
          <Menu.Item
            position='right'
            onClick={props.handleGoToCards}
            icon='th'
          >
          </Menu.Item>
          <Menu.Item
            position='right'
            active={false}
          >
            <NewOfferModal
              newOfferFormOpen={newOfferFormOpen}
              handleNewOfferFormOpen={handleNewOfferFormOpen}
              handleNewOfferFormClose={handleNewOfferFormClose}
           />
          </Menu.Item>
          <Menu.Item
            position='right'
            active={false}
            icon='ordered list'
            onClick={props.handleGoToInvoices}
          >

          </Menu.Item>
          <Menu.Item
            position='right'
            active={false}
            onClick={props.handleLogOut}
            icon='log out'
          />
        </Menu.Menu>
      </Menu>

      <Container position='middle' width='450'>
        {branchView(props)}
      </Container>
    </>
  );
};

export default MainScreen;
