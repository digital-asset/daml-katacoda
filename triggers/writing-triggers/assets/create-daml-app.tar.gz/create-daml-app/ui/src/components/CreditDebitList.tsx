import React from 'react';
import {List, Grid, Segment} from 'semantic-ui-react';
import { userContext } from './App';
import InvoiceListItem from './InvoiceListItem';
import CreditListItem from './CreditListItem';
import {Invoice} from '@daml.js/create-daml-app/lib/User';
import * as damlTypes from '@daml/types';
import * as market from '@daml.js/create-daml-app';

const CreditDebitList: React.FC = () => {
  const party = userContext.useParty();

  const invoices = userContext.useStreamQueries(market.User.Invoice, () => [{obligor: party}], [party]);
  const credits = userContext.useStreamQueries(market.User.Invoice, () => [{owner: party}], [party]);
  const ledger = userContext.useLedger();
  const handleConfirmPayment = async (contractId: damlTypes.ContractId<Invoice>) => {
    await ledger.exerciseByKey(market.User.User.ConfirmPayment, party, {invoice: contractId});
    }
  return (
    <Segment>
    <Grid columns={2}>
      <Grid.Column>
        <List divided relaxed>
          <List.Header>
            <h2> Debits </h2>
          </List.Header>
          {invoices.contracts.map(invoice =>
            <InvoiceListItem
                invoice={invoice.payload}
                onPay={() => alert('Payment not implemented yet.')}
            >
            </InvoiceListItem>
          )}
        </List>
      </Grid.Column>
      <Grid.Column>
        <List divided relaxed verticalAlign='middle'>
          <List.Item>
            <h2> Credits </h2>
          </List.Item>
            {credits.contracts.map(credit =>
              <CreditListItem
                credit={credit.payload}
                onConfirmPayment={() => handleConfirmPayment(credit.contractId)}
              >
              </CreditListItem>)
            }
        </List>
      </Grid.Column>
    </Grid>
    </Segment>
  )
};


export default CreditDebitList;
