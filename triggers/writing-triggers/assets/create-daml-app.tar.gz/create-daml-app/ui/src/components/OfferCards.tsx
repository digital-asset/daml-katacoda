import React from 'react'
import {Card} from 'semantic-ui-react'
import {OfferCard} from './OfferCard'
//import { User } from '@daml.js/create-daml-app';
import { userContext } from './App';
//import { Party } from '@daml/types';
import * as market from '@daml.js/create-daml-app'
import {CreateEvent} from '@daml/ledger'

/*const toAlias = (userId: string): string =>
  userId.charAt(0).toUpperCase() + userId.slice(1);
*/
const OfferCards: React.FC = () =>
{
  //const username = userContext.useParty();
  // const myUserResult = userContext.useStreamFetchByKeys(User.User, () => [username], [username]);
  //const aliases = publicContext.useStreamQueries(User.Alias, () => [], []);
  // const myUser = myUserResult.contracts[0]?.payload;
  // const allUsers = userContext.useStreamQueries(User.User).contracts;
// USERS_END

  // Map to translate party identifiers to aliases.
  /* const partyToAlias = useMemo(() =>
    new Map<Party, string>(aliases.contracts.map(({payload}) => [payload.username, payload.alias])),
    [aliases]
  );*/

  //const myUserName = aliases.loading ? 'loading ...' : partyToAlias.get(username) ?? username;
  // const user = userContext.useUser();
  const party = userContext.useParty();
  const sellOffers = userContext.useStreamQueries(market.User.SellOffer, () => [{}], [party]);
  const ledger = userContext.useLedger();
  const handleTakeOfferRequest = async (sellOffer: CreateEvent<market.User.SellOffer>) => {
    await ledger.exerciseByKey(market.User.User.TakeSellOffer, party, {offer: sellOffer.contractId});
  }

  return (
    <Card.Group>
        {sellOffers.contracts.map(sellOffer =>
          <OfferCard
            offer={sellOffer.payload}
            handleTakeOffer={() => handleTakeOfferRequest(sellOffer)}
          >
          </OfferCard>
        )}
    </Card.Group>
  )
}

export default OfferCards;
