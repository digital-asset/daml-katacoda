import React from 'react';
import {Button, Form, FormProps, Input, TextArea} from 'semantic-ui-react';
import { userContext } from './App';
import { Party } from "@daml/types";
import * as market from '@daml.js/create-daml-app';

type Props = {
  handleCloseForm: () => void;
};

const NewOfferForm: React.FC<Props> = ({handleCloseForm}) => {
  const party = userContext.useParty();
  const [clientName, setClientName] = React.useState<string | undefined>(undefined);
  const [currentForm, setState] = React.useState<market.User.NewSellOffer>(
      {title:''
        , description:''
        , price:''
        , observers: []}
  );

  const ledger = userContext.useLedger();

  const onChange = (e: any, {name, value}: any) => {
    if (e)
      e.preventDefault()
    if (name === 'client') {
      setState({...currentForm, observers:[value]})
      setClientName(clientName, );
    }
    else
      setState({...currentForm, [name]:value})
  };

  const handleSubmit = async (event: React.FormEvent<HTMLElement>, data: FormProps) => {
    if (event)
      event.preventDefault();

    await ledger.exerciseByKey(market.User.User.NewSellOffer, clientName, currentForm);
    handleCloseForm();
  };

  return(
    <Form onSubmit={handleSubmit}>
      <Form.Field
        label='Client'
        control={Input}
        placeholder={party ?? "Client"}
        name='client'
        value={party}
        onChange={onChange}
      >
      </Form.Field>
      <Form.Field
        label='Title'
        control={Input}
        placeholder='Title'
        name='title'
        onChange={onChange}
      >
      </Form.Field>
      <Form.Field
        label='Description'
        name='description'
        control={TextArea}
        placeholder='Describe your offer'
        onChange={onChange}
      >
      </Form.Field>
      <Input
        placeholder='Price'
        labelPosition='right'
        name='price'
        onChange={onChange}
      >
      </Input>
      <Form.Group>
        <Form.Field control={Button}> Submit </Form.Field>
        <Form.Field control={Button} onClick={handleCloseForm}> Cancel </Form.Field>
      </Form.Group>
    </Form>
  );
};

export default NewOfferForm;
