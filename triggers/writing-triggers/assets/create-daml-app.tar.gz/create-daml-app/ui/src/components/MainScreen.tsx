// Copyright (c) 2022 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

import React, { useCallback, useEffect, useState } from 'react'
import { Container, Image, Menu } from 'semantic-ui-react'
import MainView from './MainView';
import {View} from './App';
import { User } from '@daml.js/create-daml-app';
import { PublicParty } from '../Credentials';
import { userContext } from './App';
import CreditDebitList from './CreditDebitList';
import NewOfferModal from './NewOfferModal';
import OfferCards from './OfferCards';

type Props = {
  onLogout: () => void;
  getPublicParty : () => PublicParty;
  handleGoToInvoices: () => void;
  handleGoToCards: () => void;
  activeView: View;
}

const toAlias = (userId: string): string =>
  userId.charAt(0).toUpperCase() + userId.slice(1);

/**
 * React component for the main screen of the `App`.
 */
const MainScreen: React.FC<Props> = (props) => {
  const [newOfferFormOpen, openNewOfferForm] = useState(false);
  const handleNewOfferFormOpen = () => openNewOfferForm(true);
  const handleNewOfferFormClose = () => openNewOfferForm(false);
  const user = userContext.useUser();
  const party = userContext.useParty();
  const {usePublicParty, setup} = props.getPublicParty();
  const setupMemo = useCallback(setup, [setup]);
  useEffect(setupMemo);
  const publicParty = usePublicParty();

  const ledger = userContext.useLedger();

  const [createdUser, setCreatedUser] = useState(false);
  const [createdAlias, setCreatedAlias] = useState(false);

  const createUserMemo = useCallback(async () => {
    try {
      let userContract = await ledger.fetchByKey(User.User, party);
      if (userContract === null) {
        const user = {username: party, following: []};
        userContract = await ledger.create(User.User, user);
      }
      setCreatedUser(true);
    } catch(error) {
      alert(`Unknown error:\n${JSON.stringify(error)}`);
    }
  }, [ledger, party]);

  const createAliasMemo = useCallback(async () => {
    if (publicParty) {
      try {
        let userAlias = await ledger.fetchByKey(User.Alias, {_1: party, _2: publicParty});
        if (userAlias === null) {
           await ledger.create(User.Alias, {username: party, alias: toAlias(user.userId), public: publicParty});
        }
      } catch(error) {
        alert(`Unknown error:\n${JSON.stringify(error)}`);
      }
      setCreatedAlias(true);
    }
  }, [ledger, user, publicParty, party]);

  useEffect(() => {createUserMemo();} , [createUserMemo])
  useEffect(() => {createAliasMemo();} , [createAliasMemo])

  const branchView = (props: Props) => {
    switch (props.activeView.kind) {
      case 'invoices' :
        return(
          <>
           <CreditDebitList>
           </CreditDebitList>
          </>
        )
      case 'cards' :
        return (
          <>
            <OfferCards />
          </>
        )
    }
  }

  if (!(createdUser && createdAlias)) {
    return <h1>Logging in...</h1>;
  } else {
    return (
      <>
        <Menu icon borderless>
          <Menu.Item>
            <Image
              as='a'
              href='https://www.daml.com/'
              target='_blank'
              src='/daml.svg'
              alt='DAML Logo'
              size='mini'
            />
          </Menu.Item>
          <Menu.Menu position='right'>
            <Menu.Item position='right'>
              You are logged in as &nbsp; <strong>{user.userId}</strong>.
            </Menu.Item>
            <Menu.Item
              position='right'
              onClick={props.handleGoToCards}
              icon='th'
            >
            </Menu.Item>
            <Menu.Item
              position='right'
              active={false}
            >
              <NewOfferModal
                newOfferFormOpen={newOfferFormOpen}
                handleNewOfferFormOpen={handleNewOfferFormOpen}
                handleNewOfferFormClose={handleNewOfferFormClose}
             />
            </Menu.Item>
            <Menu.Item
              position='right'
              active={false}
              icon='ordered list'
              onClick={props.handleGoToInvoices}
            >

            </Menu.Item>
            <Menu.Item
              position='right'
              active={false}
              onClick={props.onLogout}
              icon='log out'
            />
          </Menu.Menu>
        </Menu>

        <Container position='middle' width='450'>
          {branchView(props)}
        </Container>
      </>
    );
  }
};

export default MainScreen;
