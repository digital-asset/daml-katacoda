import React from 'react';
import {Button, Form, FormProps, Input, TextArea} from 'semantic-ui-react';
import * as market from '@daml.js/market';
import { userContext } from './App';
import { Party } from '@daml/types';

type Props = {
    handleCloseForm: () => void;
    partyToAlias: Map<Party, string>;
};

const NewOfferForm: React.FC<Props> = ({handleCloseForm, partyToAlias}) => {
  const party = userContext.useParty();
  const [currentForm, setState] = React.useState<market.Market.NewSellOffer>(
      {title:''
        , description:''
        , price:''
        , observers: []}
  );

  const ledger = userContext.useLedger();

  const onChange = (e: any, {name, value}: any) => {
    if (e)
      e.preventDefault()
    if (name === 'client')
      setState({...currentForm, observers:[value]})
    else
      setState({...currentForm, [name]:value})
  };

  const handleSubmit = async (event: React.FormEvent<HTMLElement>, data: FormProps) => {
    if (event)
      event.preventDefault();
    await ledger.exerciseByKey(market.Market.User.NewSellOffer, party, currentForm);
    handleCloseForm();
  };

  const aliasToOption = (party: string, alias: string) => {
    return { key: party, text: alias, value: party };
  };
  const options = Array.from(partyToAlias.entries()).map(e =>
    aliasToOption(e[0], e[1]),
  );

  return(
    <Form onSubmit={handleSubmit}>
      <Form.Select
          fluid
          search
          allowAdditions
          label='Client'
          placeholder="Client"
          options={options}
          name='client'
          onAddItem={onChange}
          onChange={onChange}
      />
      <Form.Field
        label='Title'
        control={Input}
        placeholder='Title'
        name='title'
        onChange={onChange}
      >
      </Form.Field>
      <Form.Field
        label='Description'
        name='description'
        control={TextArea}
        placeholder='Describe your offer'
        onChange={onChange}
      >
      </Form.Field>
      <Input
        placeholder='Price'
        labelPosition='right'
        name='price'
        onChange={onChange}
      >
      </Input>
      <Form.Group>
        <Form.Field control={Button}> Submit </Form.Field>
        <Form.Field control={Button} onClick={handleCloseForm}> Cancel </Form.Field>
      </Form.Group>
    </Form>
  );
};

export default NewOfferForm;
